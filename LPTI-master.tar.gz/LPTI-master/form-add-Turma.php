<?php
    require 'init.php';
?>
<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">
        <a href = "turmaRegistro.php"><img src = "images/setaVoltar.png"></a><br>
        <!-- Post -->
        <form method ="post" name="formCadastro" action ="add-Turma.php" enctype="multipart/form-data">
        <h2>Cadastro de Turmas</h2>
            <table width="100%">
                <tr>
                    <th width="18%">Nome da Turma</th>
                    <td width="82%"><input type="text" name="txtNomeTurma"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnEnviar" value="Cadastrar"></td>
                    <td><input type="reset" name="btnLimpar" value="Limpar"></td>
                </tr>
            </table>
        </form>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav v-->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li class="current"><a href="alunoRegistro.html">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>
					
				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>

	</body>
</html>
