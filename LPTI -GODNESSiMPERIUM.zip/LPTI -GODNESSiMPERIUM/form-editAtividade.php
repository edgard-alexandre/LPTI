<?php
	require 'init.php';
	//pega o ID da URL
	$PDO = db_connect();
	$aux = $_GET["id"];
	$sql = "SELECT idAtividade,nomeAtividade,valorAtividade,bimestreAtividade,tipoAtividade,idTurmaAtividade FROM Atividade WHERE idAtividade = :idAtividade ORDER BY nomeAtividade ASC";
	$stmt = $PDO->prepare($sql);
	$stmt->execute(array(':idAtividade' => $aux));
	$Atividade = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
<body> 
<!-- Content -->
<div id="content"> 
    <div class="inner">
        <a href = "atividadeRegistro.php?id=<?php echo $aux ?>"><img src = "images/setaVoltar.png"></a><br>
        <!-- Post -->
        <form method ="post" name="editarAtividade" action ="editAtividade.php?id=<?php echo $Atividade['idAtividade'] ?>" enctype="multipart/form-data">
        <h2>Alterando informações da Atividade</h2>
            <table width="100%">
                    <th width="18%">Nome da Atividade</th>
                    <td width="82%"><input type="text" name="txtNomeAtividade" value="<?php echo $Atividade['nomeAtividade']?>"></td>
                 </tr>
                <tr>
                    <th>Valor da Atividade</th>
                    <td><input type="text" name="txtValorAtividade" value="<?php echo $Atividade['valorAtividade']?>"></td>
                </tr>
                 <tr>
                    <th>Bimestre da Atividade</th>
                    <td><select name="txtBimestreAtividade">
	    					<option value="1º Bimestre">1º Bimestre</option>
							<option value="2º Bimestre">2º Bimestre</option>
							<option value="3º Bimestre">3º Bimestre</option>
							<option value="4º Bimestre">4º Bimestre</option>
  						</select>
					</td>
                </tr>
                <tr>
                    <th>Tipo da Atividade</th>
                    <td><input type="text" name="txtTipoAtividade" value="<?php echo $Atividade['tipoAtividade']?>"></td>
                </tr>
                <tr>
                    <td><input type="hidden" id="IdTurmaAtividade" name="txtIdTurmaAtividade" value="<?php echo $Atividade['idTurmaAtividade']?>"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnEnviar" value="Salvar"></td>
                    <td><input type="reset" name="btnLimpar" value="Limpar"></td>
                </tr>
            </table>
        </form>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav v-->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li class="current"><a href="alunoRegistro.html">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>
				<!-- Calendar -->
					<section class="box calendar">
						<div class="inner">
							<table>
								<caption>Março 2016</caption>
								<thead>
									<tr>
										<th scope="col" title="Monday">M</th>
										<th scope="col" title="Tuesday">T</th>
										<th scope="col" title="Wednesday">W</th>
										<th scope="col" title="Thursday">T</th>
										<th scope="col" title="Friday">F</th>
										<th scope="col" title="Saturday">S</th>
										<th scope="col" title="Sunday">S</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td colspan="4" class="pad"><span>&nbsp;</span></td>
										<td><span>1</span></td>
										<td><span>2</span></td>
										<td><span>3</span></td>
									</tr>
									<tr>
										<td><span>4</span></td>
										<td><span>5</span></td>
										<td><a href="#">6</a></td>
										<td><span>7</span></td>
										<td><span>8</span></td>
										<td><span>9</span></td>
										<td><a href="#">10</a></td>
									</tr>
									<tr>
										<td><span>11</span></td>
										<td><span>12</span></td>
										<td><span>13</span></td>
										<td class="today"><a href="#">14</a></td>
										<td><span>15</span></td>
										<td><span>16</span></td>
										<td><span>17</span></td>
									</tr>
									<tr>
										<td><span>18</span></td>
										<td><span>19</span></td>
										<td><span>20</span></td>
										<td><span>21</span></td>
										<td><span>22</span></td>
										<td><a href="#">23</a></td>
										<td><span>24</span></td>
									</tr>
									<tr>
										<td><a href="#">25</a></td>
										<td><span>26</span></td>
										<td><span>27</span></td>
										<td><span>28</span></td>
										<td class="pad" colspan="3"><span>&nbsp;</span></td>
									</tr>
								</tbody>
							</table>
						</div>
					</section>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>

	</body>
</html>
