<?php
    require_once 'init.php';
    // abre a conexão
    $PDO = db_connect();
	$aux = $_GET["id"];
    $pnota = NULL;
    $snota = NULL;
    $tnota = NULL;
    $qnota = NULL;
    // SQL para selecionar os registros
    $sql = "SELECT idAluno, nomeAluno, matricula, frequencia, idTurmaAluno FROM Aluno WHERE idAluno = :idAluno ORDER BY nomeAluno ASC";
	$sql2 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade, tipoAtividade, idTurmaAtividade FROM Atividade WHERE idTurmaAtividade = :idTurmaAtividade && bimestreAtividade = '1º Bimestre' ORDER BY bimestreAtividade ASC";
    $sql3 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade, tipoAtividade, idTurmaAtividade FROM Atividade WHERE idTurmaAtividade = :idTurmaAtividade && bimestreAtividade = '2º Bimestre' ORDER BY bimestreAtividade ASC";
    $sql4 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade, tipoAtividade, idTurmaAtividade FROM Atividade WHERE idTurmaAtividade = :idTurmaAtividade && bimestreAtividade = '3º Bimestre' ORDER BY bimestreAtividade ASC";
    $sql5 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade, tipoAtividade, idTurmaAtividade FROM Atividade WHERE idTurmaAtividade = :idTurmaAtividade && bimestreAtividade = '4º Bimestre' ORDER BY bimestreAtividade ASC";
    $sql6 = "SELECT idNota, idAtividade, idAluno, valorNota FROM Nota WHERE idAluno = :idAlunoNota";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
	$stmt2 = $PDO->prepare($sql2);
    $stmt3 = $PDO->prepare($sql3);
    $stmt4 = $PDO->prepare($sql4);
    $stmt5 = $PDO->prepare($sql5);
    $stmt6 = $PDO->prepare($sql6);
    $stmt->execute(array(':idAluno' => $aux));
?>

<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
      <link rel="stylesheet" href="assets/css/style.css" />
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/skel.min.js"></script>
        <script src="assets/js/utilScreen.js"></script>
        <script src="assets/js/mainScreen.js"></script>
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">

        <!-- Post -->
        <article class="box post post-excerpt">
                <!--
                    Note: Titles and subtitles will wrap automatically when necessary, so don't worry
                    if they get too long. You can also remove the <p> entirely if you don't
                    need a subtitle.
                -->
        <?php $Aluno = $stmt->fetch(PDO::FETCH_ASSOC)?>
		<a href = "alunoLista.php?id=<?php echo $Aluno['idTurmaAluno']?>"><img src = "images/setaVoltar.png"></a><br>
            <h2><p><?php echo $Aluno['nomeAluno']?></p></h2> 
            <h3><p><?php echo $Aluno['matricula']?></p></h3>
                
            <?php $stmt2->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
            <?php $stmt3->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
            <?php $stmt4->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
            <?php $stmt5->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
            <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>  
            
            <?php $nota['1'] = $Aluno['idAluno']; ?>
            
            <?php while($Atividade = $stmt2->fetch(PDO::FETCH_ASSOC)): ?>
                <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                    <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                        <?php $pnota = $pnota + $Nota['valorNota']; ?>
                    <?php endif; ?>
                <?php endwhile; ?>
                <?php $stmt6 = $PDO->prepare($sql6); ?>
                <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
            <?php endwhile; ?>
            <?php $stmt2 = $PDO->prepare($sql2);?>
            <?php $stmt2->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
            
            <form method ="post" name="formCadastro" enctype="multipart/form-data">
                <table>
                    <input type="hidden" name="notaTxt" value="<?php echo $Aluno['idAluno']?>">
                </table>
            </form>
        
			<div class="table-responsive">			
			<table class="table table-striped">
                <tr id="bim">
                    <td><h5><b>1º Bimestre</b></h5></td>
                    <td><h5> </h5></td>
					<td><h5> </h5></td>
                    <td ><h5><b>Nota Bimestral: <?php echo $pnota ?></b></h5></td>
                </tr>
				<tr>
					<td><h5><b>ATIVIDADE</b></h5></td>
					<td><h5><b>TIPO</b></h5></td>
					<td><h5><b>VALOR</b></h5></td>
                    <td><h5><b>NOTA</b></h5></td>
				</tr>
			    <form method="post" action="editNota.php?id=<?php echo $aux ?>">
				 <?php while($Atividade = $stmt2->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $Atividade['nomeAtividade'] ?></td>
                            <td><?php echo $Atividade['valorAtividade'] ?></td>
                            <td><?php echo $Atividade['tipoAtividade'] ?></td>
                            <td id = "<?php echo $Atividade['idAtividade'] ?>"><a href = "add-Nota.php?id=<?php echo $Atividade['idAtividade']?>&id2=<?php echo $Aluno['idAluno']?>">add</a></td>
                            <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                                <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                                    <script>
                                        $("#<?php echo $Atividade['idAtividade'] ?>").hide();
                                    </script>
                                    <td><input type="number" step="any" name="nota[<?php echo $Nota['idNota']?>]" value="<?php echo $Nota['valorNota']?>"></td> 
                                    <?php $pnota = $pnota + $Nota['valorNota']; ?>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        </tr>
                        <?php $stmt6 = $PDO->prepare($sql6); ?>
                        <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                  <?php endwhile; ?>
              
                
                <?php while($Atividade = $stmt3->fetch(PDO::FETCH_ASSOC)): ?>
                    <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                            <?php $snota = $snota + $Nota['valorNota']; ?>
                        <?php endif; ?>
                    <?php endwhile; ?>
                    <?php $stmt6 = $PDO->prepare($sql6); ?>
                    <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                <?php endwhile; ?>
                <?php $stmt3 = $PDO->prepare($sql3);?>
                <?php $stmt3->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
                
                <tr id="bim">
                    <td><h5><b>2º Bimestre</b></h5></td>
                    <td><h5> </h5></td>
					<td><h5> </h5></td>
                    <td ><h5><b>Nota Bimestral: <?php echo $snota ?></b></h5></td>
                </tr>
				<tr>
					<td><h5><b>ATIVIDADE</b></h5></td>
					<td><h5><b>VALOR</b></h5></td>
					<td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>NOTA</b></h5></td>
				</tr>
				 <?php while($Atividade = $stmt3->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $Atividade['nomeAtividade'] ?></td>
                            <td><?php echo $Atividade['valorAtividade'] ?></td>
                            <td><?php echo $Atividade['tipoAtividade'] ?></td>
                            <td id = "<?php echo $Atividade['idAtividade'] ?>"><a href = "add-Nota.php?id=<?php echo $Atividade['idAtividade']?>&id2=<?php echo $Aluno['idAluno']?>">add</a></td>
                            <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                                <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                                    <script>
                                        $("#<?php echo $Atividade['idAtividade'] ?>").hide();
                                    </script>
                                    <td><input type="number" step="any" name="nota[<?php echo $Nota['idNota']?>]" value="<?php echo $Nota['valorNota']?>"></td> 
                                    <?php $snota = $snota + $Nota['valorNota']; ?>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        </tr>
                        <?php $stmt6 = $PDO->prepare($sql6); ?>
                        <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                    <?php endwhile; ?>
                
                <?php while($Atividade = $stmt4->fetch(PDO::FETCH_ASSOC)): ?>
                    <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                            <?php $tnota = $tnota + $Nota['valorNota']; ?>
                        <?php endif; ?>
                    <?php endwhile; ?>
                    <?php $stmt6 = $PDO->prepare($sql6); ?>
                    <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                <?php endwhile; ?>
                <?php $stmt4 = $PDO->prepare($sql4);?>
                <?php $stmt4->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
                
                <tr id="bim">
                    <td><h5><b>3º Bimestre</b></h5></td>
                    <td><h5> </h5></td>
					<td><h5> </h5></td>
                    <td ><h5><b>Nota Bimestral: <?php echo $tnota ?></b></h5></td>
                </tr>
				<tr>
					<td><h5><b>ATIVIDADE</b></h5></td>
					<td><h5><b>TIPO</b></h5></td>
					<td><h5><b>VALOR</b></h5></td>
                    <td><h5><b>NOTA</b></h5></td>
				</tr>
				 <?php while($Atividade = $stmt4->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $Atividade['nomeAtividade'] ?></td>
                            <td><?php echo $Atividade['valorAtividade'] ?></td>
                            <td><?php echo $Atividade['tipoAtividade'] ?></td>
                            <td id = "<?php echo $Atividade['idAtividade'] ?>"><a href = "add-Nota.php?id=<?php echo $Atividade['idAtividade']?>&id2=<?php echo $Aluno['idAluno']?>">add</a></td>
                            <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                                <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                                    <script>
                                        $("#<?php echo $Atividade['idAtividade'] ?>").hide();
                                    </script>
                                    <td><input type="number" step="any" name="nota[<?php echo $Nota['idNota']?>]" value="<?php echo $Nota['valorNota']?>"></td> 
                                    <?php $tnota = $tnota + $Nota['valorNota']; ?>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        </tr>
                        <?php $stmt6 = $PDO->prepare($sql6); ?>
                        <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                    <?php endwhile; ?>
        
                <?php while($Atividade = $stmt5->fetch(PDO::FETCH_ASSOC)): ?>
                    <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                            <?php $qnota = $qnota + $Nota['valorNota']; ?>
                        <?php endif; ?>
                    <?php endwhile; ?>
                    <?php $stmt6 = $PDO->prepare($sql6); ?>
                    <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                <?php endwhile; ?>
                <?php $stmt5 = $PDO->prepare($sql5);?>
                <?php $stmt5->execute(array(':idTurmaAtividade' => $Aluno['idTurmaAluno'])); ?>
                
                <tr id="bim">
                    <td><h5><b>4º Bimestre</b></h5></td>
                    <td><h5> </h5></td>
					<td><h5> </h5></td>
                    <td ><h5><b>Nota Bimestral: <?php echo $qnota ?></b></h5></td>
                </tr>
				<tr>
					<td><h5><b>ATIVIDADE</b></h5></td>
					<td><h5><b>VALOR</b></h5></td>
					<td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>NOTA</b></h5></td>
				</tr>
				 <?php while($Atividade = $stmt5->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $Atividade['nomeAtividade'] ?></td>
                            <td><?php echo $Atividade['valorAtividade'] ?></td>
                            <td><?php echo $Atividade['tipoAtividade'] ?></td>
                            <td id = "<?php echo $Atividade['idAtividade'] ?>"><a href = "add-Nota.php?id=<?php echo $Atividade['idAtividade']?>&id2=<?php echo $Aluno['idAluno']?>">add</a></td>
                            <?php while($Nota = $stmt6->fetch(PDO::FETCH_ASSOC)): ?>
                                <?php if($Nota['idAtividade'] == $Atividade['idAtividade']): ?>
                                    <script>
                                        $("#<?php echo $Atividade['idAtividade'] ?>").hide();
                                    </script>
                                    <td><input type="number" step="any" name="nota[<?php echo $Nota['idNota']?>]" value="<?php echo $Nota['valorNota']?>"></td> 
                                    <?php $qnota = $qnota + $Nota['valorNota']; ?>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        </tr>
                        <?php $stmt6 = $PDO->prepare($sql6); ?>
                        <?php $stmt6->execute(array(':idAlunoNota' => $aux)); ?>   
                    <?php endwhile; ?>
            </tbody>
        </table>
        </div>
          
        </article>
    
		<!--EXCLUIR Turma, EDITAR Turma e Salvar Aterações-->
        <a onClick = "if(confirm('Tem certeza que deseja excluir permanentemente este aluno?')) location.href = 'deleteAluno.php?id=<?php echo $Aluno['idAluno']?>';"><img src = "images/pbi_deleteicon.png"></a>
        <a href='form-editAluno.php?id=<?php echo $Aluno['idAluno']?>'>Editar</a>
        <button type="submit">Salvar Alterações</button>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li class="current"><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
			<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</body>
</html>
