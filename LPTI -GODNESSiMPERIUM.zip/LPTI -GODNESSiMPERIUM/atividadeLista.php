<?php
    require_once 'init.php';
    //abre a conexão
    $PDO = db_connect();
    //SQL para selecionar os registros
    $sql = "SELECT idTurma, nomeTurma FROM Turma ORDER BY nomeTurma ASC";
    $sql1 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade,tipoAtividade, idTurmaAtividade FROM Atividade WHERE bimestreAtividade = '1º Bimestre' ORDER BY nomeAtividade ASC";
    $sql2 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade,tipoAtividade, idTurmaAtividade FROM Atividade WHERE bimestreAtividade = '2º Bimestre' ORDER BY nomeAtividade ASC";
    $sql3 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade,tipoAtividade, idTurmaAtividade FROM Atividade WHERE bimestreAtividade = '3º Bimestre' ORDER BY nomeAtividade ASC";
    $sql4 = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade,tipoAtividade, idTurmaAtividade FROM Atividade WHERE bimestreAtividade = '4º Bimestre' ORDER BY nomeAtividade ASC";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
    $stmt1 = $PDO->prepare($sql1);
    $stmt2 = $PDO->prepare($sql2);
    $stmt3 = $PDO->prepare($sql3);
    $stmt4 = $PDO->prepare($sql4);
    $stmt->execute();
    $stmt1->execute();
    $stmt2->execute();
    $stmt3->execute();
    $stmt4->execute();
?> 

<!DOCTYPE HTML>
<html>
<head>
    <title>Imperium</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
    <link rel="stylesheet" href="assets/css/mainScreen.css" />
    <!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
    <link rel="stylesheet" href="assets/css/style.css"/>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">

        <!-- Post -->
        <article class="box post post-excerpt">
            <header>
                <!--
                    Note: Titles and subtitles will wrap automatically when necessary, so don't worry
                    if they get too long. You can also remove the <p> entirely if you don't
                    need a subtitle.
                -->
			<h2>Lista de Atividades</h2>
            </header>
				<div class="table-responsive">            
            <table class="table table-responsive">
                <tr id="bim">
                    <td><h4><b>1º Bimestre</b></h4></td>
                    <td><h5> </h5></td>
					<td><h5> </h5></td>
                    <td> </td>
                </tr>
                <tr>
                    <td><h5><b>ATIVIDADE</b></h5></td>
                    <td><h5><b>TURMA</b></h5></td>
                    <td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>VALOR</b></h5></td>
                </tr>
                <?php while($Atividade = $stmt1->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><a href = "atividadeRegistro.php?id=<?php echo $Atividade['idAtividade']?>"><?php echo $Atividade['nomeAtividade']?><a></td>
                    <?php while($Turma = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Atividade['idTurmaAtividade'] == $Turma['idTurma']): ?>
                                <td><?php echo $Turma['nomeTurma'] ?></td> 
                        <?php endif; ?>
                    <?php endwhile;?>
                    <td><?php echo $Atividade['tipoAtividade']?></td>
                    <td><?php echo $Atividade['valorAtividade']?></td>
                </tr>
                <?php $stmt = $PDO->prepare($sql); ?>
                <?php $stmt->execute(); ?>
                <?php endwhile;?>
                <tr id="bim">
                    <td><h4><b>2º Bimestre</b></h4></td>
                    <td><h5> </h5></td>
                    <td><h5> </h5></td>
                    <td> </td>
                </tr>
                <tr>
                    <td><h5><b>ATIVIDADE</b></h5></td>
                    <td><h5><b>TURMA</b></h5></td>
                    <td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>VALOR</b></h5></td>
                </tr>
                <?php while($Atividade = $stmt2->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><a href = "atividadeRegistro.php?id=<?php echo $Atividade['idAtividade']?>"><?php echo $Atividade['nomeAtividade']?></a></td>
                    <?php while($Turma = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Atividade['idTurmaAtividade'] == $Turma['idTurma']): ?>
                                <td><?php echo $Turma['nomeTurma'] ?></td> 
                        <?php endif; ?>
                    <?php endwhile;?>
                    <td><?php echo $Atividade['tipoAtividade']?></td>
                    <td><?php echo $Atividade['valorAtividade']?></td>
                </tr>
                <?php $stmt = $PDO->prepare($sql); ?>
                <?php $stmt->execute(); ?>
                <?php endwhile;?>
                 <tr id="bim">
                    <td><h4><b>3º Bimestre</b></h4></td>
                    <td><h5> </h5></td>
                    <td><h5> </h5></td>
                    <td> </td>
                </tr>
                <tr>
                    <td><h5><b>ATIVIDADE</b></h5></td>
                    <td><h5><b>TURMA</b></h5></td>
                    <td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>VALOR</b></h5></td>
                </tr>
                <?php while($Atividade = $stmt3->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><a href = "atividadeRegistro.php?id=<?php echo $Atividade['idAtividade']?>"><?php echo $Atividade['nomeAtividade']?></a></td>
                    <?php while($Turma = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Atividade['idTurmaAtividade'] == $Turma['idTurma']): ?>
                                <td><?php echo $Turma['nomeTurma'] ?></td> 
                        <?php endif; ?>
                    <?php endwhile;?>
                    <td><?php echo $Atividade['tipoAtividade']?></td>
                    <td><?php echo $Atividade['valorAtividade']?></td>
                </tr>
                <?php $stmt = $PDO->prepare($sql); ?>
                <?php $stmt->execute(); ?>
                <?php endwhile;?>
                 <tr id="bim">
                    <td><h4><b>4º Bimestre</b></h4></td>
                    <td><h5> </h5></td>
                    <td><h5> </h5></td>
                    <td> </td>
                </tr>
                <tr>
                    <td><h5><b>ATIVIDADE</b></h5></td>
                    <td><h5><b>TURMA</b></h5></td>
                    <td><h5><b>TIPO</b></h5></td>
                    <td><h5><b>VALOR</b></h5></td>
                </tr>
                <?php while($Atividade = $stmt4->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><a href = "atividadeRegistro.php?id=<?php echo $Atividade['idAtividade']?>"><?php echo $Atividade['nomeAtividade']?></a></td>
                    <?php while($Turma = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <?php if($Atividade['idTurmaAtividade'] == $Turma['idTurma']): ?>
                                <td><?php echo $Turma['nomeTurma'] ?></td> 
                        <?php endif; ?>
                    <?php endwhile;?>
                    <td><?php echo $Atividade['tipoAtividade']?></td>
                    <td><?php echo $Atividade['valorAtividade']?></td>
                </tr>
                <?php $stmt = $PDO->prepare($sql); ?>
                <?php $stmt->execute(); ?>
                <?php endwhile;?>
            <a href="form-add-Atividade.php" class="btn btn-primary">Nova Atividade</a><br><br><br>
            </table>
            </div>
            </article>
    </div>
</div>
    
    <!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li class="current"><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
			<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</body>
</html>
