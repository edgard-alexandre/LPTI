<?php
    require_once 'init.php';
    //abre a conexão
    $PDO = db_connect();
    //SQL para selecionar os registros
    $sql = "SELECT idTurma, nomeTurma FROM Turma ORDER BY nomeTurma ASC";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
    $stmt->execute();
?>  
<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">
        <a href = "atividadeLista.php"><img src = "images/setaVoltar.png"></a><br>
        <!-- Post -->
        <form method ="post" name="formCadastro" action ="add-Atividade.php" enctype="multipart/form-data">
        <h2>Cadastro de Atividades</h2>
            <table width="100%">
                <tr>
                    <th width="18%">Nome</th>
                    <td width="82%"><input type="text" name="txtAtividade"></td>
                 </tr>
                <tr>
                    <th>Turma</th>
                    <td>
						<select name="c">
							<?php while($Turma = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
	    						<option value="<?php echo $Turma['nomeTurma']?>"><?php echo $Turma['nomeTurma']?></option>
							<?php endwhile;?>
  						</select>
					</td>
                </tr>
                <tr>
                    <th>Bimestre</th>
                    <td>
						<select name="txtBimestreAtividade">
	    					<option value="1º Bimestre">1º Bimestre</option>
							<option value="2º Bimestre">2º Bimestre</option>
							<option value="3º Bimestre">3º Bimestre</option>
							<option value="4º Bimestre">4º Bimestre</option>
  						</select>					
					</td>
                </tr>
                <tr>
                    <th>Tipo</th>
                    <td><input type="text" id="tipoAtividade" name="txtTipoAtividade"></td>
                </tr>
                <tr>
                    <th>Valor</th>
                    <td><input type="text" id="valorAtividade" name="txtValorAtividade"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnEnviar" class="btn btn-primary" value="Cadastrar"></td>
                    <td><input type="reset" name="btnLimpar" class="btn btn-primary" value="Limpar"></td>
                </tr>
            </table>
        </form>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav v-->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li><a href="alunoRegistro.html">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li class="current"><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
            <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

	</body>
</html>
