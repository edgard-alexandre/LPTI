# Trabalho-LPTI
Arquivos do trabalho de LPTI - Pedro 2016

Imperium - Seu Gerenciador Pessoal de Registros Acadêmicos. Criado com muito amor, carinho e raiva por:
  -Pedro Barbosa;
  -Edgard Alexandre;
  -Larissa Rodrigues;
  -Willian Alves;
Nao venda isso, serio, se não vai conseguir.
2016 - CEFET-MG Varginha
