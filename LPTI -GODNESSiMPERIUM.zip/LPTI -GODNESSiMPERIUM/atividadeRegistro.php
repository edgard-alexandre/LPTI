<?php
    require_once 'init.php';
    // abre a conexão
    $PDO = db_connect();
	$id = $_GET["id"];
    // SQL para selecionar os registros
	$sql = "SELECT idAtividade, nomeAtividade, valorAtividade, bimestreAtividade, tipoAtividade, idTurmaAtividade FROM Atividade WHERE idAtividade = :idAtividade ORDER BY bimestreAtividade ASC";
    $sql2 = "SELECT idAluno, nomeAluno, matricula, frequencia, idTurmaAluno FROM Aluno WHERE idTurmaAluno = :idTurmaAluno ORDER BY nomeAluno ASC";
    $sql3 = "SELECT idNota, idAtividade, idAluno, valorNota FROM Nota WHERE idAtividade = :idAtividadeNota";
    $sql4 = "SELECT idTurma, nomeTurma FROM Turma WHERE idTurma = :idTurma";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
	$stmt2 = $PDO->prepare($sql2);
    $stmt3 = $PDO->prepare($sql3);
    $stmt4 = $PDO->prepare($sql4);
    $stmt->execute(array(':idAtividade' => $id));
	$aux=0;
    $cont=0;
?>

<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
      <link rel="stylesheet" href="assets/css/style.css" />
       <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/skel.min.js"></script>
        <script src="assets/js/utilScreen.js"></script>
        <script src="assets/js/mainScreen.js"></script>
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">

        <!-- Post -->
        <article class="box post post-excerpt">
                <!--
                    Note: Titles and subtitles will wrap automatically when necessary, so don't worry
                    if they get too long. You can also remove the <p> entirely if you don't
                    need a subtitle.
                -->
        <?php $Atividade = $stmt->fetch(PDO::FETCH_ASSOC)?>
		<a href = "atividadeLista.php"><img src = "images/setaVoltar.png"></a><br>
            <?php $stmt4->execute(array(':idTurma' => $Atividade['idTurmaAtividade'])); ?>
            <?php $Turma = $stmt4->fetch(PDO::FETCH_ASSOC)?>
            
            <h2><p><?php echo $Atividade['nomeAtividade']?></p></h2>
            <h3><p><?php echo $Turma['nomeTurma']?> - <?php echo $Atividade['bimestreAtividade']?></p></h3>
            <h3><p>Valor: <?php echo $Atividade['valorAtividade']?></p></h3> 
            <?php
            $turmaAtividade = $Atividade['idTurmaAtividade'];
        
            $stmt2->execute(array(':idTurmaAluno' => $turmaAtividade));
            $stmt3->execute(array(':idAtividadeNota' => $Atividade['idAtividade']));
        ?>
            
         <?php if($stmt2->fetch(PDO::FETCH_ASSOC) == NULL){
                    $cont = 1;
                }
                $stmt2 = $PDO->prepare($sql2);
                $stmt2->execute(array(':idTurmaAluno' => $turmaAtividade));
                ?>    
            
        <form method="post" action="editNotaAtividade.php?id=<?php echo $id ?>">
			<div class="table-responsive">			
			<table class="table table-striped">
				<tr id = "bim1">
					<td><h5><b>ALUNO</b></h5></td>
					<td><h5><b>MATRICULA</b></h5></td>
                    <td><h5><b>NOTA</b></h5></td>
				</tr>
				 <?php while($Aluno = $stmt2->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><a href = "alunoRegistro.php?id=<?php echo $Aluno['idAluno']?>"><?php echo $Aluno['nomeAluno'] ?></a></td>
                            <td><?php echo $Aluno['matricula'] ?></td>

                            <td id = "<?php echo $aux?>"><a href = "add-NotaAtividade.php?id=<?php echo $Atividade['idAtividade']?>&id2=<?php echo $Aluno['idAluno']?>">add</a></td>
                            <?php while($Nota = $stmt3->fetch(PDO::FETCH_ASSOC)): ?>
                                <?php if($Nota['idAluno'] == $Aluno['idAluno']): ?>
                                    <script>
                                        $("#<?php echo $aux?>").hide();
                                    </script>
                                    <td><input id="nota[<?php echo $Nota['idNota']?>]" type="number" step="any" name="nota[<?php echo $Nota['idNota']?>]" value="<?php echo $Nota['valorNota']?>"></td>
                                <?php $a = $Atividade['valorAtividade'] * 0.6; ?>
                                    <script>
                                        <?php if($Nota['valorNota'] < $a && $Nota['valorNota'] != NULL){?> 
                                            document.getElementById("nota[<?php echo $Nota['idNota']?>]").id = "semMediaAtividade";  
                                        <?php } ?>
                                    </script> 
                                <?php endif; ?>
                            <?php endwhile; ?>

                        </tr>  
                    <?php $stmt3 = $PDO->prepare($sql3); ?>
                    <?php $stmt3->execute(array(':idAtividadeNota' => $Atividade['idAtividade'])); ?>
					<?php $aux = $aux + 1;?>
                <?php endwhile; ?>
                 <?php if($cont > 0){ ?>
                        <tr>
                            <td>Nenhum registro encontrado</td>    
                        </tr>    
                    <?php }  ?>
                
        </table>
        </div>
        </article>
    
		<!--EXCLUIR Aluno-->
        <a onClick = "if(confirm('Tem certeza que deseja excluir permanentemente este aluno?')) location.href = 'deleteAtividade.php?id=<?php echo $Atividade['idAtividade']?>';" class="btn btn-primary">Excluir Atividade</a>
        <a href='form-editAtividade.php?id=<?php echo $id ?>' class="btn btn-primary">Editar Atividade</a>
        <button type="submit" class="btn btn-primary">Salvar Alterações</button>    
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li class="current"><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
			<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</body>
</html>
