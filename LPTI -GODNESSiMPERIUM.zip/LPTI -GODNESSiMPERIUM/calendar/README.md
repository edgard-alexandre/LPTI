# FullCalendar-BS3-PHP-MySQL
FullCalendar 2 integration with bootstrap, php and mysql

## DEMO and Installtion
[demo](http://jamelbaz.com/non-classe/integration-de-fullcalendar2-php-mysql).

## License

MIT
