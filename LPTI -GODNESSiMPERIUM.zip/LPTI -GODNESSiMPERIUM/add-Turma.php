<?php
 require_once 'init.php';
 include_once 'Turma.class.php';
 // pega os dados do formulário
 $nomeTurma = isset($_POST['txtNomeTurma']) ? $_POST['txtNomeTurma'] : null;
 $qtdAula = isset($_POST['txtQtdAula']) ? $_POST['txtQtdAula'] : null;

 // validação simples se campos estão vazios
 
 if (empty($nomeTurma) || empty($qtdAula)){
    echo "Campos devem ser preenchidos!!";
    exit;
 }
 
 // instancia objeto turma
 $Turma = new Turma($nomeTurma, $qtdAula);

 // insere no BD
 $PDO = db_connect();
 $sql = "INSERT INTO Turma(nomeTurma, qtdAula) VALUES (:nomeTurma, :qtdAula)";
 $stmt = $PDO->prepare($sql);
 $stmt->bindParam(':nomeTurma', $Turma->getNomeTurma());
 $stmt->bindParam(':qtdAula', $Turma->getQtdAula());
 if($stmt->execute()){
     header ("Location:turmaRegistro.php");
 }else{
    echo "Erro ao cadastrar!!";
    print_r($stmt->errorInfo());
 }
?>