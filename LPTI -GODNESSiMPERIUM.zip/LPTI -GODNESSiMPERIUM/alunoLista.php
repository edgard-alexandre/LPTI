<?php
    require_once 'init.php';
    // abre a conexão
    $PDO = db_connect();
	$aux = $_GET["id"];
    // SQL para selecionar os registros
    $sql = "SELECT idAluno, nomeAluno, matricula, frequencia FROM Aluno WHERE idTurmaAluno = :idTurma ORDER BY nomeAluno ASC";
	$sql2 = "SELECT idTurma, nomeTurma, qtdAula FROM Turma WHERE idTurma = :idTurma ORDER BY nomeTurma ASC";
    // conta o total de registros
   	//$stmt_count = $PDO->prepare($sql_count);
    //$stmt_count->execute();
    //$total = $stmt_count->fetchColumn();
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
	$stmt2 = $PDO->prepare($sql2);
    $stmt->execute(array(':idTurma' => $aux));
	$stmt2->execute(array(':idTurma' => $aux));
    $cont=0;
?>

<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
        <link rel="stylesheet" href="assets/css/style.css"/>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">

        <!-- Post -->
        <article class="box post post-excerpt">
            <header>
                <!--
                    Note: Titles and subtitles will wrap automatically when necessary, so don't worry
                    if they get too long. You can also remove the <p> entirely if you don't
                    need a subtitle.
                -->
		<a href = "turmaRegistro.php"><img src = "images/setaVoltar.png"></a><br>
        <h2>
			<?php $Turma = $stmt2->fetch(PDO::FETCH_ASSOC)?>
			<p><?php echo $Turma['nomeTurma']?></p>
            <h4><?php echo $Turma['qtdAula']?> Aulas/ano</h4>
		</h2>
            </header>
			<div class="table-responsive">			
			<table class="table table-striped">
				<tr id="listaAluno">
					<td><h5><b>NOME</h5></b></td>
					<td><h5><b>MATRÍCULA</b></h5></td>
					<td><h5><b>FREQUÊNCIA ANUAL</b></h5></td>
				</tr>
                <form method="post" action="editFrequencia.php?id=<?php echo $aux ?>&id2=<?php echo $Turma['qtdAula'] ?>">

                <?php if($stmt->fetch(PDO::FETCH_ASSOC) == NULL){
                    $cont = 1;
                }
                $stmt = $PDO->prepare($sql);
                $stmt->execute(array(':idTurma' => $aux));
                ?>
                    
				 <?php while($Aluno = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
				<tr>
                    <td><a href = "alunoRegistro.php?id=<?php echo $Aluno['idAluno']?>"><?php echo $Aluno['nomeAluno'] ?></a></td>
					<td><?php echo $Aluno['matricula'] ?></a></td>
            <td><input type = "number" name = "freq[<?php echo $Aluno['idAluno']?>]" value = "<?php echo $Aluno['frequencia'] ?>"></td>
                    <td> 
                        <!--<a href="form-edit-clientes.php?id=<?php echo $cliente['idCliente'] ?>"> Editar
                        </a>
                        <a href="delete-clientes.php?id=<?php echo $cliente['idCliente'] ?>"
                           onclick="return confirm('Tem certeza que deseja excluir?');">  Excluir
                        </a>-->
                    </td>
                </tr>
                <?php endwhile; ?>
				<a href="form-add-Aluno.php?id=<?php echo $Turma['idTurma'] ?>" class="btn btn-primary" role="button">Novo Aluno</a><br><br><br><br>
                <!--editAluno.php?id="ID TURMA COMO PARÂMETRO"-->
                <?php if($cont > 0){ ?>
                        <tr>
                            <td>Nenhum registro encontrado</td>    
                        </tr>    
                    <?php }  ?>
            </tbody>
        </table>
        </div>
        </article>
		<!--EXCLUIR Turma-->
			<a onClick = "if(confirm('Tem certeza que deseja excluir permanentemente esta turma?')) location.href = 'deleteTurma.php?id=<?php echo $Turma['idTurma']?>';" class="btn btn-primary" role="button">Excluir Turma</a>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href='form-editTurma.php?id=<?php echo $Turma['idTurma']?>' class="btn btn-primary" role="button">Editar Turma</a>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li class="current"><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>

				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
			<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</body>
</html>
