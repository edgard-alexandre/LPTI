<?php
    require_once 'init.php';
    include_once 'Nota.class.php';
    // abre a conexão
    $PDO = db_connect();
	$idAtividade = $_GET["id"];

    $idAluno = $_GET["id2"];

    $valorNota = NULL;

    $Nota = new Nota($idAtividade, $idAluno, $valorNota);

    $sql = "INSERT INTO Nota(idAtividade, idAluno, valorNota) VALUES(:idAtividade, :idAluno, :valorNota)";
    $stmt = $PDO->prepare($sql);
    $stmt->bindParam(':idAtividade', $Nota->getIdAtividade());		
    $stmt->bindParam(':idAluno', $Nota->getIdAluno());
    $stmt->bindParam(':valorNota', $Nota->getValorNota());
    if($stmt->execute()){
        header ("Location:alunoRegistro.php?id=$idAluno");
    }else{
        echo "Erro ao cadastrar!!";
        print_r($stmt->errorInfo());
    }
?>